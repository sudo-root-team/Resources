# from pwn import *
import zlib
import base64
import sys

def crc32(x):
	return zlib.crc32(bytes(x)) & 0xffffffff

raw = bytearray(base64.b32decode(open('{}'.format(sys.argv[1]), 'rb').read()))

N = raw[0]
L = (N + 1) * N

header = raw[:-24 - L * 2 + 2]
print('N = ' + str(N))

print('header:')
print(hexdump(header))

computer = raw[-24 - L * 2 + 2: -24 - L + 1]
player   = raw[-24 - L + 1    : -24]

crc1 = u64(raw[-24:-16])
crc2 = u64(raw[-16:-8])
crc3 = u64(raw[-8:])

crc1_start = 0
crc1_stop = 0
for i in range(len(raw)):
    for j in range(i+1, len(raw)):
        if crc32(raw[i:j]) == crc1:
            print(i,j)
            crc1_start = i
            crc1_stop = j

# Sink ships
######### Assuming scenario #1
assert header[crc1_stop] == 0xa
assert header[crc1_stop+1] == 0xa
assert header[crc1_stop+92] == 1
assert header[crc1_stop+93] == 1
assert header[crc1_stop+94] == 1
assert header[crc1_stop+95] == 1
assert header[crc1_stop+96] == 2
assert header[crc1_stop+97] == 2
assert header[crc1_stop+98] == 2
assert header[crc1_stop+99] == 3
assert header[crc1_stop+100] == 3
assert header[crc1_stop+101] == 3
# Cheats:
for i in range(92, 101+1):
    header[crc1_stop+i] = b"\x00"
    header[crc1_stop+1] -= 1
assert header[crc1_stop+1] == 0
# Set all computer ships to sunken
computer = computer.replace(b"*", b"!")
######### Assumption stop


crc1 = crc32(header[crc1_start:crc1_stop])
crc2 = crc32(computer)
print(hexdump(computer, width=16))

print('player crc:', hex(crc32(player)))
print('computer crc:', hex(crc32(computer)))

print('crc1', hex(crc1), hex(crc32(raw[crc1_start:crc1_stop])))
print('crc2', hex(crc2), hex(crc32(computer)))
print('crc3', hex(crc3), hex(crc32(player)))

# print(base64.b32encode(header + computer + player + p64(crc1) + p64(crc2) + p64(crc3)))

